## Using DWIN Icon Tool

### Splitting .ICO FIle
* Paste .ICO file into this folder
* Run Split-ICO.bat (windows only)
* A new folder should appear containing all icons

### Creating a .ICO File
* Paste in a folder full of DWIN icons
* Add "-Icons" to the end of the folder name
* Make sure there are no spaces in the name
* Run Create-ICO.bat (windows only)
* A .ICO file should appear
