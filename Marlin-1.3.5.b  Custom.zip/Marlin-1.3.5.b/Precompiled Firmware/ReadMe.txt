Precompiled builds have been moved to the releases section of github. Check them out here: https://github.com/Jyers/Marlin/releases
